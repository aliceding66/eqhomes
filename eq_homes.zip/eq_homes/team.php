<?php
echo "string";
    // include( './wp-load.php' ); // load up WordPress
    // wp_nav_menu( array ( 'menu' => 'whatever' ); // spit out a menu called 'menu'
 ?>
